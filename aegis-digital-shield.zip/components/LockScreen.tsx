
import React, { useState, useEffect } from 'react';

interface LockScreenProps {
  onUnlock: (password: string) => boolean;
  isStealth: boolean;
}

const LockScreen: React.FC<LockScreenProps> = ({ onUnlock, isStealth }) => {
  const [password, setPassword] = useState('');
  const [error, setError] = useState(false);
  const [showInput, setShowInput] = useState(false);
  
  // Fake Stats
  const [stats, setStats] = useState({ cpu: 12, ram: 45, net: 2.4 });

  useEffect(() => {
    const interval = setInterval(() => {
      setStats({
        cpu: Math.floor(Math.random() * 20) + 10,
        ram: Math.floor(Math.random() * 5) + 40,
        net: parseFloat((Math.random() * 5).toFixed(1))
      });
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!onUnlock(password)) {
      setError(true);
      setTimeout(() => setError(false), 1000);
      setPassword('');
    }
  };

  return (
    <div className="fixed inset-0 bg-[#020617] flex flex-col p-6 z-50 font-mono overflow-hidden">
      {/* Decoy Diagnostic Interface */}
      <div className="flex-1 flex flex-col">
        <div className="flex justify-between items-center mb-10 border-b border-slate-800 pb-4">
          <div className="flex items-center gap-2">
            <i className="fa-solid fa-microchip text-slate-500"></i>
            <span className="text-xs text-slate-400 font-bold uppercase tracking-widest">System Hardware Diagnostic v4.2.0</span>
          </div>
          <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <DecoyCard label="CPU LOAD" value={`${stats.cpu}%`} sub="STABLE" color="sky" />
          <DecoyCard label="RAM USAGE" value={`${stats.ram}%`} sub="8.2GB USED" color="emerald" />
          <DecoyCard label="NETWORK" value={`${stats.net} MB/S`} sub="ENCRYPTED" color="amber" />
        </div>

        <div className="bg-slate-900/50 border border-slate-800 p-6 rounded-xl flex-1 overflow-hidden relative">
          <div className="text-[10px] text-emerald-500/70 space-y-1 mb-4">
            <p>> initializing hardware link...</p>
            <p>> kernel verified: 5.15.0-generic</p>
            <p>> checking sector integrity... 100% OK</p>
            <p>> thermal sensors: 42°C</p>
            <p>> background sync active</p>
          </div>
          <div className="h-full bg-black/40 rounded border border-slate-800/50 p-4 relative flex flex-col justify-end items-center">
             <div className="absolute top-0 left-0 w-full h-1 bg-sky-500/20 animate-scan pointer-events-none"></div>
             
             <div className="w-full text-center space-y-4 mb-4">
               <p className="text-[10px] text-slate-700 animate-pulse">ENCRYPTION LAYER 1 ACTIVE</p>
               {/* This is the "Secret" trigger styled as a boring diagnostic button */}
               <button 
                 onClick={() => setShowInput(true)}
                 className="px-6 py-2 border border-slate-800 text-slate-600 text-[10px] uppercase font-bold hover:bg-slate-800/50 hover:text-slate-400 transition-all active:scale-95"
               >
                 View Advanced Error Logs
               </button>
             </div>
          </div>
        </div>
      </div>

      {/* Hidden Master Authentication */}
      {showInput && (
        <div className="absolute inset-0 bg-black/90 backdrop-blur-md flex items-center justify-center p-4">
           <div className="w-full max-w-md glass p-8 rounded-3xl border border-cyan-500/30">
              <div className="flex justify-between items-center mb-6">
                 <h2 className="text-lg font-orbitron font-bold text-cyan-400">COMMAND OVERRIDE</h2>
                 <button onClick={() => setShowInput(false)} className="text-slate-500 hover:text-white">
                    <i className="fa-solid fa-xmark"></i>
                 </button>
              </div>
              <p className="text-xs text-slate-400 mb-6">Enter the 15+ character Phantom Key to reveal the Aegis Subsystem.</p>
              
              <form onSubmit={handleSubmit} className="space-y-4">
                 <input 
                   type="password"
                   autoFocus
                   maxLength={100}
                   value={password}
                   onChange={(e) => setPassword(e.target.value)}
                   className={`w-full bg-black border p-4 rounded-xl text-center tracking-[0.3em] font-bold outline-none transition-all ${
                     error ? 'border-rose-500 text-rose-500 animate-shake' : 'border-cyan-500/50 text-cyan-400 focus:border-cyan-400'
                   }`}
                   placeholder="PHANTOM_KEY_REQUIRED"
                 />
                 <div className="flex justify-between text-[10px] text-slate-600 uppercase font-bold px-1">
                   <span>Auth: Alphanumeric</span>
                   <span>Chars: {password.length} (Min 15)</span>
                 </div>
                 <button className="w-full bg-cyan-600 hover:bg-cyan-500 text-white font-bold py-4 rounded-xl shadow-[0_0_15px_rgba(8,145,178,0.4)] transition-all">
                    INITIATE DECRYPTION
                 </button>
              </form>
           </div>
        </div>
      )}

      <style>{`
        @keyframes scan {
          from { top: 0; }
          to { top: 100%; }
        }
        .animate-scan { animation: scan 4s linear infinite; }
        @keyframes shake {
          0%, 100% { transform: translateX(0); }
          25% { transform: translateX(-5px); }
          75% { transform: translateX(5px); }
        }
        .animate-shake { animation: shake 0.2s ease-in-out infinite; }
      `}</style>
    </div>
  );
};

const DecoyCard = ({ label, value, sub, color }: any) => (
  <div className="bg-slate-900/50 border border-slate-800 p-4 rounded-xl">
    <p className="text-[10px] text-slate-500 font-bold mb-1 uppercase">{label}</p>
    <p className={`text-2xl font-bold text-${color}-500`}>{value}</p>
    <p className="text-[9px] text-slate-600 mt-1 uppercase tracking-tighter">{sub}</p>
  </div>
);

export default LockScreen;
