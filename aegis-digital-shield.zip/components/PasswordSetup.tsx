
import React, { useState } from 'react';

interface PasswordSetupProps {
  onComplete: (pwd: string) => void;
}

const PasswordSetup: React.FC<PasswordSetupProps> = ({ onComplete }) => {
  const [step, setStep] = useState(1);
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');

  const handleFinish = () => {
    const currentInput = step === 1 ? password : confirmPassword;
    
    if (currentInput.length < 15) {
      setError('Minimum 15 characters required for high-security.');
      return;
    }
    
    if (step === 1) {
      setStep(2);
      setError('');
    } else {
      if (password === confirmPassword) {
        onComplete(password);
      } else {
        setError('Passwords mismatch. Resetting.');
        setTimeout(() => {
          setPassword('');
          setConfirmPassword('');
          setStep(1);
        }, 1500);
      }
    }
  };

  return (
    <div className="fixed inset-0 bg-[#020617] flex items-center justify-center p-4 z-[100] font-mono">
      <div className="w-full max-w-md glass p-10 rounded-[3rem] border-cyan-500/30 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-1 bg-cyan-500 animate-pulse"></div>
        
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-cyan-500/10 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-cyan-500/30">
            <i className="fa-solid fa-vault text-cyan-400 text-2xl"></i>
          </div>
          <h2 className="text-xl font-orbitron font-bold text-white uppercase tracking-widest">
            {step === 1 ? 'CREATE MASTER KEY' : 'CONFIRM MASTER KEY'}
          </h2>
          <p className="text-slate-500 text-[10px] mt-2 leading-relaxed uppercase">
            {step === 1 
              ? 'This 15+ character passphrase is the only way to reveal the shield and change settings.' 
              : 'Re-enter the Phantom Key to finalize system encryption.'}
          </p>
        </div>

        <div className="space-y-6">
          <div className="relative">
            <input 
              type="text"
              maxLength={100}
              value={step === 1 ? password : confirmPassword}
              onChange={(e) => step === 1 ? setPassword(e.target.value) : setConfirmPassword(e.target.value)}
              className="w-full bg-black border border-cyan-900 focus:border-cyan-400 p-4 rounded-xl text-center text-cyan-400 font-bold outline-none transition-all tracking-widest"
              placeholder="ENTER_PASSPHRASE"
            />
            <div className="mt-2 flex justify-between items-center text-[9px] font-bold text-slate-600">
               <span>LEN: {step === 1 ? password.length : confirmPassword.length}/15 MIN</span>
               <span>ALPHANUMERIC ENFORCED</span>
            </div>
          </div>

          {error && <p className="text-rose-500 text-[10px] text-center uppercase font-bold animate-pulse">{error}</p>}

          <button 
            onClick={handleFinish}
            className="w-full bg-cyan-600 hover:bg-cyan-500 text-white font-bold py-4 rounded-2xl transition-all shadow-[0_0_20px_rgba(8,145,178,0.3)]"
          >
            {step === 1 ? 'PROCEED TO VERIFICATION' : 'ACTIVATE PHANTOM SHIELD'}
          </button>
        </div>

        <div className="mt-8 text-center">
           <p className="text-[9px] text-slate-700 uppercase">Warning: If lost, the shield cannot be deactivated.</p>
        </div>
      </div>
    </div>
  );
};

export default PasswordSetup;
