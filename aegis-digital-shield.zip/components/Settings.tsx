
import React, { useState } from 'react';
import { AppConfig } from '../types';

interface SettingsProps {
  config: AppConfig;
  onUpdate: (newConfig: Partial<AppConfig>) => void;
  onDeactivate: (pwd: string) => boolean;
}

const Settings: React.FC<SettingsProps> = ({ config, onUpdate, onDeactivate }) => {
  const [showDeactivate, setShowDeactivate] = useState(false);
  const [deactivatePwd, setDeactivatePwd] = useState('');
  const [error, setError] = useState(false);

  const handleDeactivate = () => {
    if (!onDeactivate(deactivatePwd)) {
      setError(true);
      setTimeout(() => setError(false), 2000);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-12 pb-24">
      {/* 1. PRIMARY PROTECTION TOGGLES */}
      <section className="glass p-8 rounded-3xl border border-rose-500/30 shadow-[0_0_30px_rgba(225,29,72,0.1)]">
        <h2 className="text-xl font-orbitron font-bold mb-8 text-rose-500 flex items-center gap-3 border-b border-rose-500/20 pb-4">
          <i className="fa-solid fa-shield-halved"></i>
          BLOCKING PROTOCOLS
        </h2>
        
        <div className="space-y-10">
          <ToggleItem 
            title="Escort & Prostitution Shield"
            desc="Heuristic blocking for sugar portals, escort directories, and solicitation sites."
            enabled={config.blockEscortSites}
            onToggle={() => onUpdate({ blockEscortSites: !config.blockEscortSites })}
            color="rose"
          />
          
          <ToggleItem 
            title="Global Adult Content"
            desc="DNS-level enforcement for all adult industry domains."
            enabled={config.blockAdultContent}
            onToggle={() => onUpdate({ blockAdultContent: !config.blockAdultContent })}
            color="rose"
          />

          <ToggleItem 
            title="Dopamine Loop Block"
            desc="Prevents access to Shorts, Reels, and TikTok domains to maximize focus."
            enabled={config.blockShortVideos}
            onToggle={() => onUpdate({ blockShortVideos: !config.blockShortVideos })}
            color="sky"
          />
        </div>
      </section>

      {/* 2. STEALTH & DISGUISE SETTINGS */}
      <section className="glass p-8 rounded-3xl border border-cyan-500/30">
        <h2 className="text-xl font-orbitron font-bold mb-8 text-cyan-400 flex items-center gap-3 border-b border-cyan-500/20 pb-4">
          <i className="fa-solid fa-user-secret"></i>
          STEALTH CONFIG
        </h2>
        
        <div className="space-y-10">
          <ToggleItem 
            title="Active Stealth Mode"
            desc="Show decoy 'System Diagnostic' screen when locked. Use hidden gesture (double-tap logs) to unlock."
            enabled={config.isStealthMode}
            onToggle={() => onUpdate({ isStealthMode: !config.isStealthMode })}
            color="cyan"
          />
          <ToggleItem 
            title="Settings Deep Freeze"
            desc="Requires 15+ char Phantom Key for ANY change in this section. Prevents accidental bypass."
            enabled={config.deepFreezeActive}
            onToggle={() => onUpdate({ deepFreezeActive: !config.deepFreezeActive })}
            color="cyan"
          />
        </div>
      </section>

      {/* 3. TIME MANAGEMENT */}
      <section className="glass p-8 rounded-3xl border border-cyan-500/30">
        <h2 className="text-xl font-orbitron font-bold mb-8 text-cyan-400 flex items-center gap-3 border-b border-cyan-500/20 pb-4">
          <i className="fa-brands fa-youtube"></i>
          TIME REGULATION
        </h2>
        <div className="space-y-8">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="text-lg font-bold">YouTube Daily Limit</h3>
              <p className="text-xs text-slate-500">Curfew for YouTube mobile and web access.</p>
            </div>
            <div className="text-right">
               <span className="text-3xl font-orbitron font-bold text-cyan-400">{config.youtubeDailyLimit}</span>
               <span className="text-xs text-slate-500 ml-1 font-bold">MINS</span>
            </div>
          </div>
          <input 
            type="range" 
            min="0" 
            max="120" 
            step="5"
            value={config.youtubeDailyLimit} 
            onChange={(e) => onUpdate({ youtubeDailyLimit: parseInt(e.target.value) })}
            className="w-full h-3 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-500 shadow-inner"
          />
          <div className="flex justify-between text-[10px] text-slate-600 font-bold uppercase tracking-widest">
            <span>0m (Full Block)</span>
            <span>60m (Moderate)</span>
            <span>120m (Max)</span>
          </div>
        </div>
      </section>

      {/* 4. EMERGENCY SYSTEM RESET */}
      <section className="glass p-8 rounded-3xl border border-rose-500/30">
        <h2 className="text-xl font-orbitron font-bold mb-8 text-rose-500 flex items-center gap-3 border-b border-rose-500/20 pb-4">
          <i className="fa-solid fa-biohazard"></i>
          CRITICAL OVERRIDE
        </h2>
        
        {!showDeactivate ? (
          <button 
            onClick={() => setShowDeactivate(true)}
            className="w-full bg-rose-600/10 border border-rose-500/40 text-rose-500 py-6 rounded-xl font-bold uppercase tracking-[0.3em] hover:bg-rose-600 hover:text-white transition-all text-xs"
          >
            Wipe System Data & Uninstall Shield
          </button>
        ) : (
          <div className="space-y-6">
            <p className="text-xs text-rose-300 uppercase font-bold text-center animate-pulse">Confirm identity with 15+ char Phantom Key to proceed with deletion.</p>
            <input 
              type="password"
              value={deactivatePwd}
              onChange={(e) => setDeactivatePwd(e.target.value)}
              className="w-full bg-black border border-rose-900 p-5 rounded-xl text-center text-rose-500 font-bold outline-none focus:border-rose-500 tracking-widest"
              placeholder="PHANTOM_KEY_REQUIRED"
            />
            {error && <p className="text-rose-500 text-[10px] text-center font-bold">AUTHENTICATION FAILED: ACCESS DENIED</p>}
            <div className="flex gap-4">
              <button 
                onClick={handleDeactivate}
                className="flex-1 bg-rose-600 text-white font-bold py-5 rounded-xl uppercase tracking-widest text-xs hover:bg-rose-500 shadow-lg"
              >
                CONFIRM DEACTIVATION
              </button>
              <button 
                onClick={() => setShowDeactivate(false)}
                className="flex-1 bg-slate-800 text-white font-bold py-5 rounded-xl uppercase tracking-widest text-xs border border-slate-700 hover:bg-slate-700"
              >
                ABORT
              </button>
            </div>
          </div>
        )}
      </section>
    </div>
  );
};

const ToggleItem = ({ title, desc, enabled, onToggle, color }: any) => (
  <div className="flex items-center justify-between gap-6 group">
    <div className="flex-1">
      <h4 className={`text-lg font-bold uppercase tracking-tight ${enabled ? (color === 'rose' ? 'text-rose-400' : 'text-cyan-400') : 'text-slate-500'}`}>{title}</h4>
      <p className="text-xs text-slate-500 leading-relaxed max-w-sm mt-1">{desc}</p>
    </div>
    <button 
      onClick={onToggle}
      className={`relative inline-flex h-8 w-14 items-center rounded-full transition-all flex-shrink-0 ${
        enabled 
        ? (color === 'rose' ? 'bg-rose-600 shadow-[0_0_20px_rgba(225,29,72,0.4)]' : 'bg-cyan-600 shadow-[0_0_20px_rgba(8,145,178,0.4)]') 
        : 'bg-slate-800'
      }`}
    >
      <span className={`inline-block h-6 w-6 transform rounded-full bg-white transition-transform ${enabled ? 'translate-x-7' : 'translate-x-1'}`} />
    </button>
  </div>
);

export default Settings;
